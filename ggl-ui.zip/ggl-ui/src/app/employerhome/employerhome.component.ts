import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employerhome',
  templateUrl: './employerhome.component.html',
  styleUrls: ['./employerhome.component.css']
})
export class EmployerhomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
