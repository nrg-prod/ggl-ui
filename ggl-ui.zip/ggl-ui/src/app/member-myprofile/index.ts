﻿export * from './member-myprofile.component';
