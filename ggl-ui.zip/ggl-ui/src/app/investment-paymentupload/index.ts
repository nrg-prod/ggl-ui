﻿export * from './investment-paymentupload.component';
